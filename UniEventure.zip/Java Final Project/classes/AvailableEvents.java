package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import classes.*;
public class AvailableEvents extends JFrame 
{
	private JTextArea displayArea;
	private JScrollPane scrollPane;
	
	public AvailableEvents()
	{
		
		Event.loadEvents();
		ImageIcon i1 = new ImageIcon("images/Event Background.png");
        Image i2 = i1.getImage().getScaledInstance(600, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 600, 600);
        image.setLayout(null);
        add(image);
		
	ImageIcon icon = new ImageIcon("images/back icon.jpg");
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setBounds(28, 20, 49, 50);
        image.add(iconLabel);
        iconLabel.addMouseListener(new MouseAdapter() {
          
            public void mouseClicked(MouseEvent e) 
			{
                new Homepage();
                dispose();
            }
        });
		
		displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Arial", Font.PLAIN, 16));
		JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(100, 100, 400, 400);
        image.add(scrollPane);
		
		
		String eventDetails = Event.displayEvents(); 
		displayArea.setText(eventDetails); 
		
		setLayout(null);
        setSize(600, 600);
        setLocation(220, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
		
		
	}	
}