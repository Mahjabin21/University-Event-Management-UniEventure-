package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import classes.*;
public class Homepage extends JFrame implements ActionListener
{
	
	private JLabel label1, label2; 
    private JButton button1, button2,button3; 
	
	public Homepage()
	{
		
        super("HOMEPAGE");
		
		JLabel BackgroundImage;
		ImageIcon image = new ImageIcon("images/bluehomepage.jpeg");
		BackgroundImage = new JLabel("",image,JLabel.CENTER);
		BackgroundImage.setBounds(0,0,600,900);
		add(BackgroundImage);

		
		label1= new JLabel("UniEventure");
		label1.setFont (new Font("Jokerman",Font.BOLD,60));
		label1.setForeground(new Color(176,196,222));
		label1.setBounds(100,60,500,70);
		BackgroundImage.add(label1);
		
        label2 = new JLabel("Stay connected with the campus events ");
		label2.setFont (new Font("Abadi",Font.BOLD,20));
		label2.setForeground(new Color(48,65,91));
		label2.setBounds(90,300,600,240);
		BackgroundImage.add(label2);
		
		button1 = new JButton("Sign Up");
		button1.setFont(new Font("Poor Richard",Font.BOLD,24));
		button1.setForeground(Color.BLACK);
		button1.setBackground(new Color(143,167,203));
		button1.setBounds(130,470,140,50);
		button1.addActionListener(this);
		BackgroundImage.add(button1);
	
		button2 = new JButton("Log In");
		button2.setFont(new Font("Poor Richard",Font.BOLD,24));
		button2.setForeground(Color.WHITE);
		button2.setBackground(new Color(77,100,137));
		button2.setBounds(310,470,140,50);
		button2.addActionListener(this);
		BackgroundImage.add(button2);	

		button3 = new JButton("Available Events");
		button3.setFont(new Font("Poor Richard",Font.BOLD,24));
		button3.setForeground(Color.WHITE);
		button3.setBackground(new Color(120,128,157));
		button3.setBounds(90,530,400,40);
		button3.addActionListener(this);
		BackgroundImage.add(button3);
		
		
		setSize(600,800);
		setLocation(350,8);
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
	}
	public void actionPerformed(ActionEvent e)
	{
		 if (e.getSource() == button1) 
		 {
            new Signup();  
            this.dispose();  
        } 
		else if (e.getSource() == button2) 
		{
            new Login();  
            this.dispose(); 
        } 
		else if (e.getSource() == button3)
		{
			new AvailableEvents();
			this.dispose();
		}
		
	}

	/*public static void main (String[]args)
	{
		new Homepage();
	}*/
}