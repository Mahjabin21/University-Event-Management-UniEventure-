package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import classes.*;

public class ParticipantForm extends JFrame implements ActionListener {
    private String username;
    private JTextArea eventDisplayArea;
    private JPanel panel;
    private JLabel messagelabel, eventNameLabel, usernameLabel, emailLabel, studentIdLabel;
    private JTextField eventNameField, usernameField, emailField, idField;
    private JButton registerButton;
    

    public ParticipantForm(String username) {
        super("Registration For Events");
        this.username = username;
        Event.loadEvents();
		
        ImageIcon i1 = new ImageIcon("images/Event Background.png");
        Image i2 = i1.getImage().getScaledInstance(900, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 900, 600);
        image.setLayout(null);
        add(image);

        ImageIcon icon = new ImageIcon("images/back icon.jpg");
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setBounds(28, 20, 49, 50);
        image.add(iconLabel);
        iconLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new UserDashboard(username);
                dispose();
            }
        });

        eventDisplayArea = new JTextArea();
        eventDisplayArea.setEditable(false);
        eventDisplayArea.setFont(new Font("Arial", Font.PLAIN, 16));

        panel = new JPanel();
        panel.setBounds(470, 80, 400, 400);
        panel.setBackground(new Color(0, 0, 228, 20));
        panel.setLayout(null);
        image.add(panel);

        messagelabel = new JLabel("Register For An Event!");
        messagelabel.setFont(new Font("Raleway", Font.BOLD, 20));
        messagelabel.setBounds(80, 30, 300, 30);
        panel.add(messagelabel);

        eventNameLabel = new JLabel("Event Name:");
        eventNameLabel.setFont(new Font("Raleway", Font.BOLD, 15));
        eventNameLabel.setBounds(20, 100, 150, 30);
        panel.add(eventNameLabel);

        eventNameField = new JTextField();
        eventNameField.setFont(new Font("Raleway", Font.BOLD, 15));
        eventNameField.setBounds(140, 100, 230, 30);
        panel.add(eventNameField);

        usernameLabel = new JLabel("User Name:");
        usernameLabel.setFont(new Font("Raleway", Font.BOLD, 15));
        usernameLabel.setBounds(20, 160, 150, 30);
        panel.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setFont(new Font("Raleway", Font.BOLD, 12));
        usernameField.setBounds(140, 160, 230, 30);
        panel.add(usernameField);

        emailLabel = new JLabel("Email ID:");
        emailLabel.setFont(new Font("Denmark", Font.BOLD, 15));
        emailLabel.setBounds(20, 220, 150, 30);
        panel.add(emailLabel);

        emailField = new JTextField();
        emailField.setFont(new Font("Raleway", Font.BOLD, 12));
        emailField.setBounds(140, 220, 230, 30);
        panel.add(emailField);

        studentIdLabel = new JLabel("Student ID:");
        studentIdLabel.setFont(new Font("Denmark", Font.BOLD, 15));
        studentIdLabel.setBounds(20, 280, 150, 30);
        panel.add(studentIdLabel);

        idField = new JTextField();
        idField.setFont(new Font("Raleway", Font.BOLD, 15));
        idField.setBounds(140, 280, 230, 30);
        panel.add(idField);

        registerButton = new JButton("Register");
        registerButton.setFont(new Font("Arial", Font.BOLD, 16));
        registerButton.setForeground(Color.WHITE);
        registerButton.setBackground(new Color(77, 100, 137));
        registerButton.setBounds(150, 340, 140, 40);
        registerButton.addActionListener(this);
        panel.add(registerButton);

       

        JScrollPane scrollPane = new JScrollPane(eventDisplayArea);
        scrollPane.setBounds(30, 80, 400, 400);
        image.add(scrollPane);


		updateEventDisplayArea();
		
        setLayout(null);
        setSize(900, 600);
        setLocation(220, 60);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == registerButton)
			{
            String eventname = eventNameField.getText();
            String username = usernameField.getText();
            String email = emailField.getText();
            String id = idField.getText();

            if (eventname.isEmpty() || username.isEmpty() || email.isEmpty() || id.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields");
                return;
            } else if (!validStudentId(id)) {
                JOptionPane.showMessageDialog(this, "Invalid Student ID");
                return;
            } else
			{
                try {
                    BufferedWriter writer = new BufferedWriter(new FileWriter(".\\Data\\participant_data.txt", true));
                    writer.write(eventname + "," + email + "," + id);
                    writer.newLine();
                    writer.close();
                    
				boolean eventExists = false;
                
                for (int i=0; i<Event.bookedEvents.size(); i++) {
					Event event = Event.bookedEvents.get(i);
                    if (event.getEventName().equalsIgnoreCase(eventname)) {
                        event.addParticipant();  
                        eventExists = true;
                        JOptionPane.showMessageDialog(this, "Registration successful for " + eventname);
                        break;
                    }
                }
                
                if (eventExists) {
                    Event.saveEvents();  
					
                } else {
                    JOptionPane.showMessageDialog(this, "Event not found!");
                }
			
					updateEventDisplayArea();
                    eventNameField.setText("");
                    usernameField.setText("");
                    emailField.setText("");
                    idField.setText("");
                } catch (IOException ie)
				{
                    ie.printStackTrace();
                }
            }
        }
    }

    public boolean validStudentId(String id) {
        if (id.length() != 10) {
            JOptionPane.showMessageDialog(this, "Student ID must be 10 characters long and in **-*****_* format(* refers to digits)");
            return false;
        }

        String[] segments = id.split("-");
        if (segments.length != 3) {
            return false;
        }

        if (segments[0].length() != 2 || segments[1].length() != 5 || segments[2].length() != 1) {
            return false;
        }

        for (int i = 0; i < segments[0].length(); i++) {
            if (!Character.isDigit(segments[0].charAt(i))) {
                return false;
            }
        }

        for (int i = 0; i < segments[1].length(); i++) {
            if (!Character.isDigit(segments[1].charAt(i))) {
                return false;
            }
        }

        if (!Character.isDigit(segments[2].charAt(0))) {
            return false;
        }

        return true;
    }
	
	private void updateEventDisplayArea() 
	{
    String eventDetails = Event.displayEvents(); 
    eventDisplayArea.setText(eventDetails); 
	}

	

}
