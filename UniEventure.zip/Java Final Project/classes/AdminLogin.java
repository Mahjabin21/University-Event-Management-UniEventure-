package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import classes.*;

public class AdminLogin extends JFrame implements ActionListener 
{
    private JPanel panel1;
    private JLabel adminLabel, userLabel, passwordLabel;
    private JTextField userField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public AdminLogin() 
    {
        super("ADMIN LOGIN");

        // Background image setup
        ImageIcon i1 = new ImageIcon("images/Event Background.png");
        Image i2 = i1.getImage().getScaledInstance(600, 750, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 600, 750);
        add(image);
        
		// Back Icon
        ImageIcon icon = new ImageIcon("images/back icon.jpg"); 
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setBounds(28, 20, 49, 50);
        image.add(iconLabel);
        iconLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new Homepage();
                dispose();
            }
        });
		
        // Transparent panel for form elements
        panel1 = new JPanel();
        panel1.setBounds(150, 200, 300, 300); 
        panel1.setBackground(new Color(33, 63, 86, 150)); // Transparent blue
        panel1.setLayout(null);  
        image.add(panel1);

        // Admin label
        adminLabel = new JLabel("Admin Login");
        adminLabel.setFont(new Font("ALGERIAN", Font.BOLD, 26));
        adminLabel.setForeground(Color.WHITE); // White text color
        adminLabel.setBounds(75, 10, 200, 50);
        panel1.add(adminLabel);

        // Username label and field
        userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Arial", Font.BOLD, 20));
        userLabel.setForeground(Color.WHITE);
        userLabel.setBounds(20, 80, 120, 30);
        panel1.add(userLabel);

        userField = new JTextField();
        userField.setFont(new Font("Arial", Font.PLAIN, 16));
        userField.setBounds(140, 80, 130, 30);
        panel1.add(userField);

        // Password label and field
        passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 20));
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setBounds(20, 130, 120, 30);
        panel1.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.PLAIN, 16));
        passwordField.setBounds(140, 130, 130, 30);
        panel1.add(passwordField);

        // Login button
        loginButton = new JButton("Log In");
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(Color.decode("#57A0D2"));
        loginButton.setBounds(80, 200, 140, 40);
        loginButton.addActionListener(this);
        panel1.add(loginButton);

        // Frame settings
        setLayout(null);
        setSize(600, 750);
        setLocation(350, 10);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        if (e.getSource() == loginButton) 
        {
            String username = userField.getText();
            String password = new String(passwordField.getPassword());

            if (username.isEmpty() || password.isEmpty()) 
            {
                JOptionPane.showMessageDialog(this, "Username or Password cannot be empty.");
            } 
            else if (existAdmin(username, password)) 
            {
                JOptionPane.showMessageDialog(this, "Login Successful!");
                new AdminDashboard(); 
                this.dispose();
            } 
            else 
            {
                JOptionPane.showMessageDialog(this, "Invalid Username or Password.");
            }
        }
    }

    private boolean existAdmin(String username, String password) 
   {
    try (BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\admin_data.txt"))) 
    {
        String line;
        while ((line = reader.readLine()) != null) 
        {
            String[] details = line.split(",");
            
            if (details[1].equals(username) && details[5].equals(password)) 
            {
                return true;
            }
        }
    } 
    catch (IOException e) 
    {
        
        e.printStackTrace();
    }
    return false;
}


    /*public static void main(String[] args) 
    {
        new AdminLogin();
    }*/
}
