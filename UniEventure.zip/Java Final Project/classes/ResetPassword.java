package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import classes.*;
public class ResetPassword extends JFrame implements ActionListener
{	private JFrame frame;
	private JPanel panel;
	private JLabel resetPassword,userEmail,newPassword;
	private JTextField emailTextfield;
	private JPasswordField newPassfield;
	private JButton resetButton,backButton;
	
	public ResetPassword(){
	
		super ("Reset Password Frame");
		setLayout(null);
        setSize(600, 750);
        setLocation(350, 10);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        	
		ImageIcon i1 = new ImageIcon("images/Event Background.png");
        Image i2 = i1.getImage().getScaledInstance(600,750,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel backgroundImage = new JLabel(i3);
        backgroundImage.setBounds(0,0,600,750);
        add(backgroundImage);
		
		panel = new JPanel();
        panel.setBounds(150, 220, 300, 230); 
        panel.setBackground(new Color(0, 0, 228, 20));
		panel.setLayout(null);
        backgroundImage.add(panel);


        resetPassword = new JLabel("Reset Password");
        resetPassword.setFont (new Font("ALGERIAN",Font.BOLD,26));
        resetPassword.setBounds(180, 170, 300, 50);
        backgroundImage.add(resetPassword);
        
        

        userEmail = new JLabel("User Email:");
        userEmail.setFont(new Font("Arial", Font.BOLD, 15));
        userEmail.setBounds(10, 20, 100, 30);
        panel.add(userEmail);

        emailTextfield = new JTextField();
        emailTextfield.setFont(new Font("Arial", Font.PLAIN, 12));
        emailTextfield.setBounds(130, 20, 160, 30);
        panel.add(emailTextfield);

        newPassword = new JLabel("New Password:");
        newPassword.setFont(new Font("Arial", Font.BOLD, 15));
        newPassword.setBounds(10, 80, 120, 30);
        panel.add(newPassword);

        newPassfield = new JPasswordField();
        newPassfield.setFont(new Font("Arial", Font.PLAIN, 12));
        newPassfield.setBounds(130, 80, 160, 30);
        panel.add(newPassfield);
		
		resetButton = new JButton("Reset");
        resetButton.setFont(new Font("Poor Richard", Font.BOLD, 20));
        resetButton.setForeground(Color.WHITE);
        resetButton.setBackground(new Color(77, 100, 137));
        resetButton.setBounds(80, 150, 140, 40); 
        resetButton.addActionListener(this);
        panel.add(resetButton);
		
		backButton = new JButton("< Back");
        backButton.setFont(new Font("Poor Richard", Font.BOLD, 20));
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(77, 100, 137));
        backButton.setBounds(20, 20, 100, 30);
       backButton.addActionListener(this);
        backgroundImage.add(backButton);

		setVisible(true);
}
public void actionPerformed(ActionEvent e)
{
	if (e.getSource() == resetButton) 
        {
            String userEmail = emailTextfield.getText();
            String newPassword = new String(newPassfield.getPassword());

            if (userEmail.isEmpty() || newPassword.isEmpty()) 
            {
                JOptionPane.showMessageDialog(this,"Email or New Password cannot be empty.");
            } 
            else if (updatePassword(userEmail,newPassword)) 
            {
                JOptionPane.showMessageDialog(this,"Password Reset Successful!");
            } 
            else 
            {
                JOptionPane.showMessageDialog(this,"There is no user with this email");
            }
        } 
        else if (e.getSource() == backButton) 
        {
            new Login();
			this.dispose();
        }
    }
	
	
		public boolean updatePassword(String userEmail, String newPassword)
		{
			StringBuilder sb = new StringBuilder();
			File file = new File(".\\Data\\user_data.txt");
		    boolean userExists = false;
			try (BufferedReader reader = new BufferedReader(new FileReader(file))) 
			{
			String line;
			
        while ((line = reader.readLine()) != null)
		{
            String[] details = line.split(",");
			
            if (details[2].equals(userEmail))
			{
    			details[5] = newPassword; 
                userExists = true;
            }
        for (int i = 0; i < details.length; i++)
		{
			sb.append(details[i]);
			if (i < details.length - 1)
			{
				sb.append(","); 
			}
		}
		sb.append("\n");
        }
			} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
	
	if (userExists) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) 
		{
            writer.write(sb.toString());
        } 
		catch (IOException e) 
		{
            e.printStackTrace();
        }
		}
		return userExists;
		}
	
	

	
    /*public static void main(String[] args) 
    {
        new ResetPassword();
    }*/
}
