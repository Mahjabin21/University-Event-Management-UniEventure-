package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import classes.*;
public class UserDashboard implements ActionListener {
	private JFrame frame;
    private JPanel userPanel;
    private JButton organizeButton, registerButton,backButton, logoutButton;
    private JLabel userNameLabel,welcomeLabel, organizeQuestion, organizeQuestion2, registerQuestion, registerQuestion2;
	private String username;
	
    public UserDashboard(String username) 
	{
		
		this.username = username;

        frame = new JFrame("User Dashboard");
        frame.setSize(700, 600);
        frame.setLocation(280, 60);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        
        // Background image setup
        ImageIcon imageIcon = new ImageIcon("images/Event Background.png");
        Image image = imageIcon.getImage().getScaledInstance(700, 600, Image.SCALE_DEFAULT);
        imageIcon = new ImageIcon(image);
        JLabel backgroundImage = new JLabel(imageIcon);
        backgroundImage.setBounds(0, 0, 700, 600); 
        frame.add(backgroundImage);

        // Side userPanel
        userPanel = new JPanel();
        userPanel.setBounds(0, 0, 230, 600);
        userPanel.setBackground(Color.decode("#04598d"));
        userPanel.setLayout(null); 
        backgroundImage.add(userPanel);

        
        ImageIcon profileIcon = new ImageIcon("images/Profile logo.png");
        Image profileImage = profileIcon.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        JLabel profileLabel = new JLabel(new ImageIcon(profileImage));
        profileLabel.setBounds(45, 50, 130, 130);
        userPanel.add(profileLabel);

        // Welcome label
        welcomeLabel = new JLabel("Welcome To UniEventure");
        welcomeLabel.setBounds(276, 50, 400, 40);
        welcomeLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 28));
        welcomeLabel.setForeground(Color.BLACK);
        backgroundImage.add(welcomeLabel);
		
		//username label below the profile
		userNameLabel = new JLabel(" " + username.toUpperCase()); 
        userNameLabel.setBounds(70, 190, 220, 50); 
        userNameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        userNameLabel.setForeground(Color.WHITE); 
        userPanel.add(userNameLabel);

		
		
        // Log out button inside the panel
        logoutButton = new JButton("Log Out");
        logoutButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
        logoutButton.setForeground(Color.BLACK);
        logoutButton.setBackground(new Color(172, 209, 228));
        logoutButton.setBounds(55, 470, 120, 40);
        logoutButton.addActionListener(this);
        userPanel.add(logoutButton);
		
		// Back button inside the panel 
		backButton = new JButton("< Back");
        backButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
        backButton.setForeground(Color.BLACK);
        backButton.setBackground(new Color(172, 209, 228));
        backButton.setBounds(55, 410, 120, 40);
        backButton.addActionListener(this);
        userPanel.add(backButton);

        // Questions for user
        organizeQuestion = new JLabel("Would you like to organize an event?");
        organizeQuestion.setBounds(320, 150, 600, 20);
        organizeQuestion.setFont(new Font("Arial", Font.BOLD, 15));
        organizeQuestion.setForeground(Color.BLACK);
        backgroundImage.add(organizeQuestion);

        organizeQuestion2 = new JLabel("If yes, then click here ");
        organizeQuestion2.setBounds(380, 180, 600, 20);
        organizeQuestion2.setFont(new Font("Arial", Font.BOLD, 15));
        organizeQuestion2.setForeground(Color.BLACK);
        backgroundImage.add(organizeQuestion2);

        registerQuestion = new JLabel("Would you like to participate in an event?");
        registerQuestion.setBounds(320, 300, 600, 20);
        registerQuestion.setFont(new Font("Arial", Font.BOLD, 15));
        registerQuestion.setForeground(Color.BLACK);
        backgroundImage.add(registerQuestion);

        registerQuestion2 = new JLabel("If yes, then click here ");
        registerQuestion2.setBounds(380, 330, 600, 20);
        registerQuestion2.setFont(new Font("Arial", Font.BOLD, 15));
        registerQuestion2.setForeground(Color.BLACK);
        backgroundImage.add(registerQuestion2);
		
		organizeButton = new JButton("Organize");
        organizeButton.setFont(new Font("Poor Richard",Font.BOLD,24));
        organizeButton.setForeground(Color.WHITE);
        organizeButton.setBackground(new Color(77,100,137));
        organizeButton.setBounds(390, 220, 150, 38);
        organizeButton.addActionListener(this);
        backgroundImage.add(organizeButton);
		
		registerButton= new JButton("Register");
        registerButton.setFont(new Font("Poor Richard",Font.BOLD,24));
        registerButton.setForeground(Color.WHITE);
        registerButton.setBackground(new Color(77,100,137));
        registerButton.setBounds(390, 370, 150, 38);
        registerButton.addActionListener(this);
        backgroundImage.add(registerButton);

        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == organizeButton)
		{
			new OrganizerDashboard(username);
			frame.dispose();
		}
		else if (e.getSource() == registerButton)
		{
			new ParticipantForm(username);
			frame.dispose();
		}
		
		if (e.getSource() == backButton) 
		{
            new Login(); 
            frame.dispose();
        
		}
        if (e.getSource() == logoutButton) 
		{
            new Homepage(); 
            frame.dispose();
        
		}
	}
    /*public static void main(String[] args) {
        new UserDashboard("TestUser");
    }*/
}
