package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import classes.*;
public class Signup extends JFrame {

    private JPanel p;
    private JLabel l1, l2, l3, l4, l5, l6;
    private JRadioButton r1, r2, r3;
    private JTextField t1, t2, t3, t4;
    private JPasswordField p1, p2;
    private ButtonGroup genderGroup;
   
    public Signup() {
        setTitle("SIGN UP");

        //background image setup
        ImageIcon i1 = new ImageIcon("images/Event Background.png");
        Image i2 = i1.getImage().getScaledInstance(630, 740, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 630, 740);
        add(image);

        // ok icon
        ImageIcon okIcon = new ImageIcon("images/Signup icon.png");
        JLabel okiconLabel = new JLabel(okIcon);
        okiconLabel.setBounds(220, 570, 150, 50);
        image.add(okiconLabel);

        okiconLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleFormSubmission(); 
            }
        });

        // Back Icon
        ImageIcon icon = new ImageIcon("images/back icon.jpg");
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setBounds(28, 20, 49, 50);
        image.add(iconLabel);
        iconLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new Homepage();
                dispose();
            }
        });
        
		//panel 
        p = new JPanel();
        p.setBounds(120, 180, 350, 360);
        p.setPreferredSize(new Dimension(800, 300));
        p.setBackground(new Color(0, 0, 228, 20));
        p.setLayout(null);
        image.add(p);
         
		//sign up label
        l1 = new JLabel("Sign Up for UniEventure");
        l1.setFont(new Font("ALGERIAN", Font.BOLD, 25));
        l1.setBounds(130, 105, 350, 50);
        image.add(l1);

        // Name label,field
        l2 = new JLabel("Name:");
        l2.setFont(new Font("Raleway", Font.BOLD, 15));
        l2.setBounds(135, 195, 100, 30);
        image.add(l2);

        t1 = new JTextField();
        t1.setFont(new Font("Raleway", Font.BOLD, 12));
        t1.setBounds(285, 200, 180, 20);
        image.add(t1);

        // Username label,field
        l3 = new JLabel("Username:");
        l3.setFont(new Font("Denmark", Font.BOLD, 15));
        l3.setBounds(135, 245, 100, 28);
        image.add(l3);

        t2 = new JTextField();
        t2.setFont(new Font("Raleway", Font.BOLD, 12));
        t2.setBounds(285, 250, 180, 20);
        image.add(t2);

        // Email ID label,field
        l4 = new JLabel("Email ID:");
        l4.setFont(new Font("Denmark", Font.BOLD, 15));
        l4.setBounds(135, 295, 200, 30);
        image.add(l4);

        t3 = new JTextField();
        t3.setFont(new Font("Raleway", Font.BOLD, 12));
        t3.setBounds(285, 300, 180, 20);
        image.add(t3);

        // Phone number label,field
        l5 = new JLabel("Phone Number:");
        l5.setFont(new Font("Denmark", Font.BOLD, 15));
        l5.setBounds(135, 345, 250, 31);
        image.add(l5);

        t4 = new JTextField();
        t4.setFont(new Font("Raleway", Font.BOLD, 12));
        t4.setBounds(285, 350, 180, 20);
        image.add(t4);

        // Gender label and radio buttons
        l6 = new JLabel("Gender:");
        l6.setFont(new Font("Denmark", Font.BOLD, 15));
        l6.setBounds(135, 390, 200, 30);
        image.add(l6);

        r1 = new JRadioButton("Male");
        r1.setBounds(280, 393, 65, 25);
        r1.setOpaque(false);
        r1.setFont(new Font("Times new roman", Font.BOLD, 13));
        image.add(r1);

        r2 = new JRadioButton("Female");
        r2.setBounds(335, 393, 65, 25);
        r2.setOpaque(false);
        r2.setFont(new Font("Times new roman", Font.BOLD, 13));
        image.add(r2);

        r3 = new JRadioButton("Others");
        r3.setBounds(400, 393, 65, 25);
        r3.setOpaque(false);
        r3.setFont(new Font("Times new roman", Font.BOLD, 13));
        image.add(r3);

        genderGroup = new ButtonGroup();
        genderGroup.add(r1);
        genderGroup.add(r2);
        genderGroup.add(r3);

        // Password label,field
        JLabel password = new JLabel("Password:");
        password.setFont(new Font("Denmark", Font.BOLD, 15));
        password.setBounds(135, 440, 200, 30);
        image.add(password);

        p1 = new JPasswordField(15);
        p1.setFont(new Font("Raleway", Font.BOLD, 12));
        p1.setBounds(285, 445, 180, 20);
        image.add(p1);

        // Confirm Password label,field
        JLabel confpassword = new JLabel("Confirm Password:");
        confpassword.setFont(new Font("Denmark", Font.BOLD, 15));
        confpassword.setBounds(135, 490, 200, 30);
        image.add(confpassword);

        p2 = new JPasswordField(15);
        p2.setFont(new Font("Raleway", Font.BOLD, 12));
        p2.setBounds(285, 495, 180, 20);
        image.add(p2);

       
       //JFrame properties
        setLayout(null);
        setSize(630, 740);
        setLocation(350, 8);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void handleFormSubmission() {
        String name = t1.getText();
        String username = t2.getText();
        String emailId = t3.getText();
        String phoneNumber = t4.getText();
        String password = new String(p1.getPassword());
        String confirmPassword = new String(p2.getPassword());

        //gender selection determining
        String gender = null;
        if (r1.isSelected()) gender = "Male";
        else if (r2.isSelected()) gender = "Female";
        else if (r3.isSelected()) gender = "Others";

        // Validation logic
        if (name.isEmpty() || username.isEmpty() || emailId.isEmpty() || phoneNumber.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please ensure all fields are filled out.");
            return;
        }

        if (gender == null) {
            JOptionPane.showMessageDialog(this, "Please select a gender.");
            return;
        }

        if (phoneNumber.length() != 11 || !phoneNumber.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "Phone number must be exactly 11 digits.");
            return;
        }

        if (password.length() < 8 || password.length() > 16) {
            JOptionPane.showMessageDialog(this, "Password must be between 8 and 16 characters long.");
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Password and Confirm Password do not match.");
            return;
        }

        if (isEmailExists(emailId)) {
            JOptionPane.showMessageDialog(this, "User with this email already exists!");
            return;
        }

        // Create and save the new user
        User newUser = new User(name, username, emailId, phoneNumber, gender, password);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(".\\Data\\user_data.txt", true))) {
            writer.write(newUser.getName() + "," + newUser.getUsername() + "," + newUser.getEmail() + "," + newUser.getPhoneNumber() + "," + newUser.getGender() + "," + newUser.getPassword() + "\n");
            JOptionPane.showMessageDialog(this, "Sign Up successful!");
            dispose();
            new Login();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
		
    //email exists method
    private boolean isEmailExists(String emailId) {
        try (BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\user_data.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                if (details[2].equals(emailId)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

   /* public static void main(String[] args) {
        new Signup();
    }*/
}

