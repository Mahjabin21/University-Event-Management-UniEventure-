package classes;
import java.lang.*;
import classes.*;
class User
{
	private String name;
	private String username;
	private String emailId;
	private String phoneNumber;
	private String gender;
	private String password;
	
	public User(String name, String username, String emailId, String phoneNumber, String gender, String password)
    {
        this.name = name;
        this.username = username;
        this.emailId = emailId;
		this.phoneNumber = phoneNumber;
		this.gender = gender;
		this.password = password;
	}	
		public String getName()
		{
			return name;
		}
		public String getUsername()
		{
			return username;
		}
		public String getEmail()
		{
			return emailId;
		}
		public String getPhoneNumber()
		{
			return phoneNumber;
		}
		public String getGender()
		{
			return gender;
		}
		public String getPassword()
		{
			return password;
		}
	
}