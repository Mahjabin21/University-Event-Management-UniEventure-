package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 
import classes.*; 
public class SelectDateFrame extends JFrame {

    private JLabel yearLabel, monthLabel, dayLabel;
    private JTextField yearField;
	private JButton okayButton;
    private JComboBox<String> monthComboBox, dayComboBox;
	private OrganizerDashboard organizerDashboard; 

    public SelectDateFrame(OrganizerDashboard dashboard) 
	{
        this.organizerDashboard = dashboard;
		
        yearLabel = new JLabel("Year:");
        yearLabel.setBounds(110, 60, 80, 30);
        yearLabel.setFont(new Font("Serif", Font.BOLD, 23));
        add(yearLabel);

        yearField = new JTextField();
        yearField.setFont(new Font("Serif", Font.BOLD, 12));
        yearField.setBounds(200, 60, 150, 30);
        add(yearField);

        monthLabel = new JLabel("Select Month:");
        monthLabel.setBounds(30, 110, 150, 30);
        monthLabel.setFont(new Font("Serif", Font.BOLD, 23));
        add(monthLabel);

        // Month ComboBox (January to December)
        String months[] = {" ","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        monthComboBox = new JComboBox<>(months);
        monthComboBox.setBounds(200, 110, 150, 30);
        monthComboBox.setFont(new Font("Serif", Font.BOLD, 15));
        add(monthComboBox);

        monthComboBox.addActionListener(new ActionListener() 
		{
            public void actionPerformed(ActionEvent e) {
                updateDays();  
            }
        });

        dayLabel = new JLabel("Select Day:");
        dayLabel.setBounds(30, 160, 150, 30);
        dayLabel.setFont(new Font("Serif", Font.BOLD, 23));
        add(dayLabel);

        
        dayComboBox = new JComboBox<>();
        dayComboBox.setBounds(200, 160, 150, 30);
        dayComboBox.setFont(new Font("Serif", Font.BOLD, 15));
        add(dayComboBox);
		
		okayButton = new JButton ("OK");
		okayButton.setBounds(140,250,100,30);
		okayButton.setForeground(Color.WHITE);
        okayButton.setBackground(new Color(77, 100, 137));
		okayButton.setFont(new Font ("Poor Richard",Font.BOLD,24));
		add(okayButton);
		okayButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String selectedDay = (String) dayComboBox.getSelectedItem();
				String selectedMonth = (String) monthComboBox.getSelectedItem();
				String selectedYear = yearField.getText();
            
            
				String selectedDate = selectedDay + "/" + selectedMonth + "/" + selectedYear;
          
				organizerDashboard.setSelectedDate(selectedDate);
				dispose();
							
			}
		});

        setSize(400, 400);
        setLayout(null);
        setLocation(350, 100);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

       
    }

    
    private int daysInMonth(String month, int year) {
        switch (month) {
            case "January":
			case "March": 
			case "May":
			case "July":
            case "August":
			case "October":
			case "December":
                return 31;
            case "April":
			case "June":
			case "September":
			case "November":
                return 30;
            case "February":
                
                if (isLeapYear(year)) {
                    return 29;
                } else {
                    return 28;
                }
            default:
                return 30; 
        }
    }

    
    private boolean isLeapYear(int year) {
        if (year > 0 ) 
		{
            return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
        }
        return false;
    }

    
    public void updateDays() {
        String selectedMonth = (String) monthComboBox.getSelectedItem();
        int year = 0;
        try {
            year = Integer.parseInt(yearField.getText());
        } catch (NumberFormatException e) 
		{
             year = 0; 
			 JOptionPane.showMessageDialog(this, "Invalid year.Please enter a valid year and try again.");
        }

        if (year < 2024) {
        JOptionPane.showMessageDialog(this, "Please enter a year from 2024 onwards.");
        return; 
		}
		
        int days = daysInMonth(selectedMonth, year);  

        for (int i = 1; i <= days; i++) {
            dayComboBox.addItem(String.valueOf(i));  
        }
    }

    /*public static void main(String[] args) 
	{
        OrganizerDashboard dashboard = new OrganizerDashboard("Test User");
        new SelectDateFrame(dashboard);
    }*/
}
