package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import classes.*;

public class Login extends JFrame implements ActionListener 
{
    private JPanel panel1;
    private JLabel label, label1, label2, label3, label4;
    private JTextField textField;
    private JPasswordField passwordField;
    private JButton loginButton;
	private String username;
    public Login() 
    {
        setTitle("LOGIN");
        
        // Background Image
        ImageIcon i1 = new ImageIcon("images/Event Background.png");
        Image i2 = i1.getImage().getScaledInstance(600, 750, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 600, 750);
        add(image);
		
		// Back Icon
        ImageIcon icon = new ImageIcon("images/back icon.jpg"); 
        JLabel iconLabel = new JLabel(icon);
        iconLabel.setBounds(28, 20, 49, 50);
        image.add(iconLabel);
        iconLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new Homepage();
                dispose();
            }
        });

        // Panel add
        panel1 = new JPanel();
        panel1.setBounds(150, 200, 300, 300); 
        panel1.setBackground(new Color(0, 0, 228, 30));
        panel1.setLayout(null);
        image.add(panel1);

        // Title label
        label = new JLabel("User Login");
        label.setFont(new Font("ALGERIAN", Font.BOLD, 26));
        label.setBounds(70, 20, 200, 50);
        panel1.add(label);

        // Username label and field
        label1 = new JLabel("Username:");
        label1.setFont(new Font("Arial", Font.BOLD, 20));
        label1.setBounds(10, 80, 200, 30);
        panel1.add(label1);

        textField = new JTextField();
        textField.setFont(new Font("Arial", Font.PLAIN, 12));
        textField.setBounds(120, 80, 173, 28);
        panel1.add(textField);

        // Password label and field
        label2 = new JLabel("Password:");
        label2.setFont(new Font("Arial", Font.BOLD, 20));
        label2.setBounds(10, 130, 200, 30);
        panel1.add(label2);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.PLAIN, 12));
        passwordField.setBounds(120, 130, 173, 28);
        panel1.add(passwordField);

        // Forgot password label
        label3 = new JLabel("Forgot Password?");
        label3.setForeground(Color.BLUE); 
        label3.setFont(new Font("Arial", Font.BOLD, 12));
        label3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        label3.setBounds(100, 180, 180, 30);
        panel1.add(label3);
        label3.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                new ResetPassword();
                dispose();  
            }
        });
		
		//Admin Label
        label4 = new JLabel("Admin");
        label4.setForeground(Color.BLUE); 
        label4.setFont(new Font("Arial", Font.BOLD, 20));
        label4.setCursor(new Cursor(Cursor.HAND_CURSOR));
        label4.setBounds(500, 20, 180, 30);
        image.add(label4);
        label4.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                new AdminLogin();
                dispose();  
            }
        });

        // Login Button
        loginButton = new JButton("Log In");
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(new Color(77, 100, 137));
        loginButton.setBounds(80, 220, 140, 40); 
        loginButton.addActionListener(this);
        panel1.add(loginButton);

        
        setLayout(null);
        setSize(600, 750);
        setLocation(350, 5);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) 
    {
        if (e.getSource() == loginButton) 
        {
             username = textField.getText();
            String password = new String(passwordField.getPassword());

            if (username.isEmpty() || password.isEmpty()) 
            {
                JOptionPane.showMessageDialog(this,"Username or Password cannot be empty.");
            } 
            else if (existUser(username, password)) 
            {
                JOptionPane.showMessageDialog(this,"Login Successful!");
                Event.loadEvents();  
                new UserDashboard(username); 
                this.dispose();
            } 
            else 
            {
                JOptionPane.showMessageDialog(this,"Invalid Username or Password.");
            }
        }
    }
    
	//email existance method
    private boolean existUser(String username, String password)
    {
        try (BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\user_data.txt")))
        {
            String line;
            while ((line = reader.readLine()) != null) 
            {
                String[] details = line.split(",");
                if (details[1].equals(username) && details[5].equals(password)) 
                {
                    return true;
                }
            }
        }
        catch (IOException E) 
        {
            E.printStackTrace();
        }
        return false;
    }

   /* public static void main(String[] args) 
    {
        new Login();
    }*/
}
