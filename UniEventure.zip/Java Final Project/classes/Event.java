package classes;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import classes.*;

public class Event {
    private String eventName;
    private String venue;
	private String category;
    private String date;  
    private String slot;
	private String availableSlot;
	private int participantCount;
    static ArrayList<Event> bookedEvents = new ArrayList<>();
    private static File file = new File(".\\Data\\events_data.txt");  

    public Event(String eventName, String venue,String category, String date, String slot,String availableSlot)	{
		setEventName(eventName);
		setVenue(venue);	
		setCategory(category);
		setDate(date);
		setSlot(slot);
		setAvailableSlot(availableSlot);
        this.participantCount=0;
    }
	
	public void setEventName(String eventName)
	{ 
	this.eventName = eventName;
	}
	public void setVenue(String venue)
	{
		this.venue = venue;
	
	}
	
	public void setCategory(String category)
	{
		this.category = category;
	
	}public void setDate(String date)
	{
		this.date = date;
	
	}public void setSlot(String slot)
	{
		this.slot= slot;
	
	}
	public void setAvailableSlot(String availableSlot) {
        this.availableSlot = availableSlot;
    }
	public void setParticipantCount(int count) {
    this.participantCount = count; 
}

    
	public String getEventName() { return eventName; }
    public String getVenue() { return venue; }
	public String getCategory() { return category; }
    public String getDate() { return date; }
    public String getSlot() { return slot; }
	public String getAvailableSlot() {return availableSlot; }

	public int getParticipantCount(){return participantCount;}
	public void addParticipant(){this.participantCount++;}




	public static void loadEvents() {
    bookedEvents.clear();
	
    try (BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\events_data.txt"))) {
        String line;
        
        while ((line = reader.readLine()) != null) {
            String[] eventData = line.split(",");
		
        
            if (eventData.length == 7) {
                String eventName = eventData[0];
                String venue = eventData[1];
				//int capacity = Integer.parseInt(eventData[2]);
                String category = eventData[3];
                String date = eventData[4];
                String slot = eventData[5];
                int participantCount = Integer.parseInt(eventData[6].trim()); 

                Event event = new Event(eventName, venue, category, date, slot,"");
                
                event.setParticipantCount(participantCount);
                bookedEvents.add(event);
				 
        }
    }}
	catch(IOException ie){ie.printStackTrace();}
	
	catch (NumberFormatException e)
	{
        System.out.println("Error reading participant count.");
    }
}


    
	
        
        
	public static void saveEvents() {
    // Create a temporary list to hold the existing event names
    ArrayList<String> existingEventNames = new ArrayList<>();
    
    try (Scanner scanner = new Scanner(file)) 
	{
        while (scanner.hasNextLine())
			{
            String[] eventData = scanner.nextLine().split(",");
            if (eventData.length == 7) 
			{
                existingEventNames.add(eventData[0].trim());
            }
        }
    } catch (FileNotFoundException e) {
        System.out.println("No previous bookings.");
    }

    // write to the file
    try (FileWriter writer = new FileWriter(file,true)) {
        for (Event event : bookedEvents) {
            if (!existingEventNames.contains(event.getEventName())) {
                writer.append(event.getEventName()).append(",")
                      .append(event.getVenue()).append(",")
                      .append(event.getCategory()).append(",")
                      .append(event.getDate()).append(",")
                      .append(event.getSlot()).append(",")
                      .append(String.valueOf(event.getParticipantCount())).append("\n");
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}
	
	
   
	// Load venues from file
    public static ArrayList<String> loadVenues() {
        ArrayList<String> venues = new ArrayList<>();
		File file = new File(".\\Data\\venue_data.txt");
		
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                venues.add(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return venues;
    }

    // Load categories from file
    public static ArrayList<String> loadCategories() {
        ArrayList<String> categories = new ArrayList<>();
		File file = new File (".\\Data\\category_data.txt");
		
		
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                categories.add(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return categories;
    }

   
     public static void bookNewEvent(Event event) {
        if ((!getBookedSlots(event.getVenue(), event.getDate()).contains(event.getSlot())) && !bookedEvents.contains(event)) {
            bookedEvents.add(event);
            saveEvents();
        }
    }

    
 
	
	 // Get booked slots for a specific venue and date
    public static ArrayList<String> getBookedSlots(String venue, String date) {
        ArrayList<String> bookedSlots = new ArrayList<>();

        for (int i = 0; i < bookedEvents.size(); i++) {
            Event event = bookedEvents.get(i);
            if (event.getVenue().equals(venue) && event.getDate().equals(date)) {
                bookedSlots.add(event.getSlot());  // Add the slot to the list if there's a clash
            }
        }

        return bookedSlots;
    }

// Get available slots by removing booked ones
    public static ArrayList<String> getAvailableSlots(String venue, String date) {
        ArrayList<String> allSlots = new ArrayList<>();

        // Assuming these are your available slots
        allSlots.add("9.00 am - 12.00 pm");
        allSlots.add("2.00 pm - 5.00 pm");

        // Get the booked slots for the given venue and date
        ArrayList<String> bookedSlots = getBookedSlots(venue, date);

        // Remove booked slots from the available slots
        allSlots.removeAll(bookedSlots);

        return allSlots;
    }
	


	public static String displayEvents() {
        if (bookedEvents.isEmpty()) {
            
            return("No events booked yet.");
        }
		
		StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bookedEvents.size(); i++) {
            Event event = bookedEvents.get(i);
            sb.append("Event Name: ").append(event.eventName).append("\n")
              .append("Venue: ").append(event.venue).append("\n")
			  .append("Category: ").append(event.category).append("\n")
              .append("Date: ").append(event.date).append("\n")
              .append("Time: ").append(event.slot).append("\n")
			  .append("Participants registered: ").append(event.participantCount).append("\n\n");
        }
        return sb.toString();
    }
		
   

public static boolean isClash(String venue, String date, String slot) {
    ArrayList<String> bookedSlots = getBookedSlots(venue, date);
    return bookedSlots.contains(slot); // Return true if the slot is booked
}


}
