package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import classes.*;

public class AdminDashboard extends JFrame implements ActionListener, FocusListener 
{
    JPanel userPanel;
    JTextField searchField, venueField, capacityField,categoryField, clientEmailField, phoneNumberField;
    JTextArea displayField;
    JScrollPane scrollPane;
    JButton homeButton, searchButton, addUserButton, userDetailsButton, addVenueButton,
	deleteVenueButton, addCategoryButton, deleteCategoryButton, findButton, deleteButton, clearButton,  allEventsButton, participantDetailsButton ;
    JLabel welcomeLabel, homeLabel;  
    JComboBox<String> venuesComboBox, categoriesComboBox;
	
    public AdminDashboard() {
		super("Admin Dashboard");
        
       

        // Background image setup
        ImageIcon i1 = new ImageIcon("images/Event Background.png");
        Image i2 = i1.getImage().getScaledInstance(700, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel backgroundImage = new JLabel(i3);
        backgroundImage.setBounds(0, 0, 700, 600);
        add(backgroundImage);

        // Side userPanel
        userPanel = new JPanel();
        userPanel.setBounds(0, 0, 230, 600);
        userPanel.setBackground(Color.decode("#04598d"));
        userPanel.setLayout(null); 
        backgroundImage.add(userPanel);

        // Profile logo inside the panel
        ImageIcon ii1 = new ImageIcon("images/Profile logo1.png");
        Image ii2 = ii1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon ii3 = new ImageIcon(ii2);
        JLabel image1 = new JLabel(ii3);
        image1.setBackground(Color.decode("#04598d"));
        image1.setBounds(48, 60, 130, 130);
        userPanel.add(image1);


        // Home button inside the panel
        homeButton = new JButton("Home");
        homeButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        homeButton.setForeground(Color.BLACK);
        homeButton.setBackground(new Color(135, 206, 235, 255));
        homeButton.setBounds(48, 224, 160, 35);
        homeButton.addActionListener(this);
        userPanel.add(homeButton);

        // Add User button inside the panel
        addUserButton = new JButton("Add User");
        addUserButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        addUserButton.setForeground(Color.BLACK);
        addUserButton.setBackground(new Color(135, 206, 235, 255));
        addUserButton.setBounds(48, 275, 160, 35);
        addUserButton.addActionListener(this);
        //addUserButton.addMouseListener(this);
        userPanel.add(addUserButton);

        // User Details button inside the panel
        userDetailsButton = new JButton("User Details");
        userDetailsButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        userDetailsButton.setForeground(Color.BLACK);
        userDetailsButton.setBackground(new Color(135, 206, 235, 255));
        userDetailsButton.setBounds(48, 326, 160, 35);
        userDetailsButton.addActionListener(this);
        //userDetailsButton.addActionListener(this);
        userPanel.add(userDetailsButton);

        // Participant Details button inside the panel
        participantDetailsButton = new JButton("Participant Details");
        participantDetailsButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        participantDetailsButton.setForeground(Color.BLACK);
        participantDetailsButton.setBackground(new Color(135, 206, 235, 255));
        participantDetailsButton.setBounds(48, 377, 160, 35);
        participantDetailsButton.addActionListener(this);
        userPanel.add(participantDetailsButton);

        // All Events button inside the panel
        allEventsButton = new JButton("All Events");
        allEventsButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        allEventsButton.setForeground(Color.BLACK);
        allEventsButton.setBackground(new Color(135, 206, 235, 255));
        allEventsButton.setBounds(48, 428, 160, 35);
        allEventsButton.addActionListener(this);
        //allEventsButton.addMouseListener(this);
        userPanel.add(allEventsButton);

        // Search box and button
        searchField = new JTextField();
        searchField.setBounds(39, 18, 130, 25);
        userPanel.add(searchField);
        //search logo
        ImageIcon is1 = new ImageIcon("images/Search2.png");
        Image is2 = is1.getImage().getScaledInstance(25, 25, Image.SCALE_DEFAULT);
        ImageIcon is3 = new ImageIcon(is2);
        searchButton = new JButton(is3);
        searchButton.setBounds(170, 18, 25, 25);
        searchButton.addActionListener(this);
        userPanel.add(searchButton);

        // Venue TextField, Add button, and Delete button
        venueField = new JTextField("Venue");
		venueField.setFont(new Font("Times New Roman", Font.BOLD, 15));
        venueField.setBounds(270, 50, 200, 35);
        venueField.addFocusListener(this);
        backgroundImage.add(venueField);

        addVenueButton = new JButton("Add");
		addVenueButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        addVenueButton.setBounds(485, 50, 70, 35);
		addVenueButton.setForeground(Color.WHITE);
		addVenueButton.setBackground(new Color(77, 100, 137));
        addVenueButton.addActionListener(this);
        backgroundImage.add(addVenueButton);

        deleteVenueButton = new JButton("Delete");
		deleteVenueButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        deleteVenueButton.setBounds(560, 50, 100, 35);
		deleteVenueButton.setForeground(Color.WHITE);
		deleteVenueButton.setBackground(new Color(77, 100, 137));
        deleteVenueButton.addActionListener(this);
        backgroundImage.add(deleteVenueButton);


		capacityField = new JTextField("Capacity");
		capacityField.setFont(new Font("Times New Roman", Font.BOLD, 15));
		capacityField.setBounds(270, 100, 200, 35);  
		capacityField.addFocusListener(this);
		backgroundImage.add(capacityField);


        // Category TextField, Add button, and Delete button
        categoryField = new JTextField("Category");
		categoryField.setFont(new Font("Times New Roman", Font.BOLD, 15));
        categoryField.setBounds(270, 150, 200, 35);
        categoryField.addFocusListener(this);
        backgroundImage.add(categoryField);

        addCategoryButton = new JButton("Add");
		addCategoryButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        addCategoryButton.setBounds(485, 150, 70, 35);
		addCategoryButton.setBackground(new Color(77, 100, 137));
		addCategoryButton.setForeground(Color.WHITE);
        addCategoryButton.addActionListener(this);
        backgroundImage.add(addCategoryButton);

        deleteCategoryButton = new JButton("Delete");
		deleteCategoryButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        deleteCategoryButton.setBounds(560, 150, 100, 35);
		deleteCategoryButton.setForeground(Color.WHITE);
		deleteCategoryButton.setBackground(new Color(77, 100, 137));
        deleteCategoryButton.addActionListener(this);
        backgroundImage.add(deleteCategoryButton);

        // Client Email and Phone Number TextFields and Find button
        clientEmailField = new JTextField("Client Email");
		clientEmailField.setFont(new Font("Times New Roman", Font.BOLD, 15));
        clientEmailField.setBounds(270, 224, 200, 35);
        clientEmailField.addFocusListener(this);
        backgroundImage.add(clientEmailField);

        phoneNumberField = new JTextField("Phone Number");
		phoneNumberField.setFont(new Font("Times New Roman", Font.BOLD, 15));
        phoneNumberField.setBounds(270, 275, 200, 35);
        phoneNumberField.addFocusListener(this);
        backgroundImage.add(phoneNumberField);

        // Display Field with Scroll Pane
        displayField = new JTextArea();
        displayField.setEditable(false);
        displayField.setForeground(Color.BLACK); 
        displayField.setBackground(new Color(211, 211, 211)); 
        displayField.setOpaque(true);

        scrollPane = new JScrollPane(displayField);
        scrollPane.setBounds(250, 365, 415, 150);
        backgroundImage.add(scrollPane);

        findButton = new JButton("Find");
		findButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
		findButton.setForeground(Color.WHITE);
		findButton.setBackground(new Color(77, 100, 137));
        findButton.setBounds(485, 275, 70, 35);
        findButton.addActionListener(this);
        backgroundImage.add(findButton);

        deleteButton = new JButton("Delete");
		deleteButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        deleteButton.setBounds(560, 275, 100, 35);
		deleteButton.setForeground(Color.WHITE);
		deleteButton.setBackground(new Color(77, 100, 137));
        deleteButton.addActionListener(this);
        backgroundImage.add(deleteButton);

        // Clear button
        clearButton = new JButton("Clear");
		clearButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
        clearButton.setBounds(400, 524, 120, 30);
		clearButton.setForeground(Color.WHITE);
		clearButton.setBackground(new Color(77, 100, 137));
        clearButton.addActionListener(this);
        backgroundImage.add(clearButton);

        setSize(700, 600);
        setLocation(280, 60);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
	//set the buttons 
	@Override
    public void actionPerformed(ActionEvent e) 
    {
		if (e.getSource() == searchButton) {
        String searchText = searchField.getText().trim();
    
        if (!searchText.isEmpty()) {
        StringBuilder result = new StringBuilder();
        
        
        // Search in Events.txt of Events, Venues, Categories...
        result.append(searchInFile(".\\Data\\events_data.txt", searchText, "Events")).append("\n");
		
        
        // Display results in the displayField
        if (result.toString().trim().isEmpty()) {
            displayField.setText("No results found for: " + searchText);
        } else {
            displayField.setText(result.toString());
        }
		
        } else {
        JOptionPane.showMessageDialog(this, "Please enter a search term.");
        }
	   
      }

        if (e.getSource() == homeButton) 
        {
            new Homepage(); 
            this.dispose();
        }
        if (e.getSource() == addUserButton) 
        {
            new Signup(); 
            this.dispose();
        }
		if (e.getSource() == userDetailsButton) 
		{
            displayField.setText(getAllUserDetails());
        }
		
        if (e.getSource() == participantDetailsButton) {
            displayField.setText(getAllParticipantDetails());
        }
		if (e.getSource() == allEventsButton) 
		{
            displayField.setText(Event.displayEvents());
        }
		
				if (e.getSource() == findButton) {
    String email = clientEmailField.getText();
    String phone = phoneNumberField.getText();
    User newUser = findUser(email, phone);

    if (newUser != null) {
        displayField.setText("Name: " + newUser.getName() + "\nUsername: " + newUser.getUsername() + "\nEmail: " + newUser.getEmail() + "\nPhone Number: " + newUser.getPhoneNumber() + "\nGender: " + newUser.getGender() + "\nPassword: " + newUser.getPassword());
    } else {
        displayField.setText("User not found.");
    }
}

		if (e.getSource() == clearButton) 
		{
            displayField.setText("");
        }
		if (e.getSource() == deleteButton) 
		{
            String email = clientEmailField.getText();
            String phone = phoneNumberField.getText();
            int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete the user with Email: " + email + " and Phone: " + phone + "?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (response == JOptionPane.YES_OPTION) 
			{
                deleteUser(email, phone);
                JOptionPane.showMessageDialog(this, "User deleted successfully.");
            }
		}
		if (e.getSource() == addVenueButton) {
            addVenue();
        } else if (e.getSource() == deleteVenueButton) {
            deleteVenue();
        } else if (e.getSource() == addCategoryButton) {
            addCategory();
        } else if (e.getSource() == deleteCategoryButton) {
            deleteCategory();
        }
		
    }
	
	
    public void focusGained(FocusEvent e) 
	{
        if (e.getSource() == venueField && venueField.getText().equals("Venue")) 
		{
            venueField.setText("");
        }
		if (e.getSource() == capacityField && capacityField.getText().equals("Capacity")) 
		{
            capacityField.setText(""); 
        }
        if (e.getSource() == categoryField && categoryField.getText().equals("Category")) 
		{
            categoryField.setText("");
        }
        if (e.getSource() == clientEmailField && clientEmailField.getText().equals("Client Email"))
		{
            clientEmailField.setText("");
        }
        if (e.getSource() == phoneNumberField && phoneNumberField.getText().equals("Phone Number")) 
		{
            phoneNumberField.setText("");
        }
    }

    @Override
    public void focusLost(FocusEvent e) 
	{
        if (e.getSource() == venueField && venueField.getText().isEmpty()) 
		{
            venueField.setText("Venue");
        }
		
		if (e.getSource()== capacityField && capacityField.getText().isEmpty()) 
		{
            capacityField.setText("Capacity");  
        }
        if (e.getSource() == categoryField && categoryField.getText().isEmpty()) 
		{
            categoryField.setText("Category");
        }
        if (e.getSource() == clientEmailField && clientEmailField.getText().isEmpty()) 
		{
            clientEmailField.setText("Client Email");
        }
        if (e.getSource() == phoneNumberField && phoneNumberField.getText().isEmpty()) 
		{
            phoneNumberField.setText("Phone Number");
        }
    }
	
	//Searching for ... 
	private String searchInFile(String fileName, String searchText, String fileType) 
    {
       StringBuilder result = new StringBuilder();
       try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) 
        {
          String line;
          while ((line = reader.readLine()) != null) 
            {
              if (line.toLowerCase().contains(searchText.toLowerCase())) 
                {
                 String[] details = line.split(",");
                 result.append("Event Name: ").append(details[0]).append("\n")
                       .append("Venue: ").append(details[1]).append("\n")
                       .append("Capacity: ").append(details[2]).append("\n")
                       .append("Category: ").append(details[3]).append("\n")
                       .append("Date: ").append(details[4]).append("\n")
                       .append("Time: ").append(details[5]).append("\n\n");
                }
            }
                if (result.length() == 0) 
                    {
                     result.append("No matches found.\n");
                    }
        } 
           catch (IOException e) 
            {
               e.printStackTrace();
               result.append("Error reading ").append(" file.\n");
            }
			return result.toString();
    }

	
	
	
	     // User details
    private String getAllUserDetails() {
    StringBuilder userDetails = new StringBuilder();
    try (BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\user_Data.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] details = line.split(",");
            User user = new User(details[0], details[1], details[2], details[3], details[4], details[5]);
            userDetails.append("Name: ").append(user.getName()).append("\n")
                       .append("Username: ").append(user.getUsername()).append("\n")
                       .append("Email: ").append(user.getEmail()).append("\n")
                       .append("Phone Number: ").append(user.getPhoneNumber()).append("\n")
                       .append("Gender: ").append(user.getGender()).append("\n")
                       .append("Password: ").append(user.getPassword()).append("\n\n");
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return userDetails.toString();
}
	
	
		//Participant Details
	private String getAllParticipantDetails() {
    StringBuilder participantDetails = new StringBuilder();
    try (BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\participant_data.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] details = line.split(",");
            participantDetails.append("Event Name: ").append(details[0]).append("\n")
                              .append("Email ID: ").append(details[1]).append("\n")
                              .append("Student ID: ").append(details[2]).append("\n\n");
        }
    } catch (IOException e) {
        e.printStackTrace();
        return "File not found.";
    }
    return participantDetails.toString();
  }
	
	//event details
     /*private String getAllEventDetails() {
        StringBuilder eventDetails = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\events_data.txt"))) {
            String line;
            while((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                eventDetails.append("Event Name: ").append(details[0]).append("\n")
                            .append("Venue: ").append(details[1]).append("\n")
                            //.append("Capacity: ").append(details[2]).append("\n")
                            .append("Category: ").append(details[2]).append("\n")
                            .append("Date: ").append(details[3]).append("\n")
                            .append("Time: ").append(details[4]).append("\n") 
							.append("Participants Registered: ").append(details[6]).append("\n\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
			JOptionPane.showMessageDialog(this,"No events booked yet");
       }
	   
        return eventDetails.toString();
    }*/
	
	
	
		//finding user by email and phoneNumber
	public User findUser(String emailId, String phone) {
    try (BufferedReader reader = new BufferedReader(new FileReader(".\\Data\\user_data.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] details = line.split(",");
            if (details[2].equals(emailId) && details[3].equals(phone)) {
                return new User(details[0], details[1], details[2], details[3], details[4], details[5]);
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return null; // Return null if user not found
}
	
	// Deleting a user
    private void deleteUser(String emailId, String phone) {
       File inputFile = new File(".\\Data\\user_data.txt");
       File tempFile = new File(".\\Data\\userData_temp.txt");

       try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
        
           String line;
           while ((line = reader.readLine()) != null) {
               String[] details = line.split(",");
               if (!(details[2].equals(emailId) && details[3].equals(phone))) {
                    writer.write(line + System.lineSeparator());
            }
        }
        
    } catch (IOException e) {
        e.printStackTrace();
      }

         if (!inputFile.delete()) {
              System.out.println("Could not delete original file");
        }

          if (!tempFile.renameTo(inputFile)) {
              System.out.println("Could not rename temp file to original file name");
        }
    }

	
	
	// Adding venues
	
	public void addVenue() {
    String venue = venueField.getText();
    String capacity = capacityField.getText();
    if (!venue.isEmpty() && !venue.equals("Venue") && !capacity.isEmpty()&& !capacity.equals("Capacity")){
        try {
            int capacitynum = Integer.parseInt(capacity);  
            try (FileWriter writer = new FileWriter(".\\Data\\venue_data.txt", true)) {
                writer.write(venue + "," + capacitynum+ "\n");  
                JOptionPane.showMessageDialog(this, "Venue added: " + venue );
				
				if(venuesComboBox!=null)
				{
				venuesComboBox.addItem(venue);
				}
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number for capacity.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Could not add venue.");
        }
		
        venueField.setText("Venue");
        capacityField.setText(""); 
    } else {
        JOptionPane.showMessageDialog(this, "Please enter a valid venue and capacity.");
    }
}
	
	

	// deleting venues
	public void deleteVenue() {
    String venueToDelete = venueField.getText();
	
    if (!venueToDelete.isEmpty() && !venueToDelete.equals("Venue")) {
        ArrayList<String> venues = Event.loadVenues();
        boolean found = false;

        for (int i = 0; i < venues.size(); i++) {
            String venue = venues.get(i);
            
            if (venue.startsWith(venueToDelete)) {
                venues.remove(i);  
                saveVenues(venues);
                JOptionPane.showMessageDialog(this, "Venue deleted: " + venueToDelete);
                found = true;
                break;
            }
        }

        if (!found) {
            JOptionPane.showMessageDialog(this, "Venue not found.");
        }

        venueField.setText("Venue");
    } else {
        JOptionPane.showMessageDialog(this, "Please enter a valid venue.");
    }
}



    // Add category method
    private void addCategory() {
        String category = categoryField.getText().trim();
        if (!category.isEmpty() && !category.equals("Category")) {
            try (FileWriter writer = new FileWriter(".\\Data\\category_data.txt", true)) {
                writer.write(category + "\n");
                JOptionPane.showMessageDialog(this, "Category added: " + category);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error adding category.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            categoryField.setText("Category");
        } else {
            JOptionPane.showMessageDialog(this, "Please enter a valid category.");
        }
    }

    // Delete category method
    private void deleteCategory() {
        String categoryToDelete = categoryField.getText().trim();
        if (!categoryToDelete.isEmpty() && !categoryToDelete.equals("Category")) {
            ArrayList<String> categories = Event.loadCategories();
            if (categories.remove(categoryToDelete)) {
                saveCategories(categories);
                JOptionPane.showMessageDialog(this, "Category deleted: " + categoryToDelete);
            } else {
                JOptionPane.showMessageDialog(this, "Category not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            categoryField.setText("Category");
        } else {
            JOptionPane.showMessageDialog(this, "Please enter a valid category.");
        }
    }

    


    // Saving venues
    private void saveVenues(ArrayList<String> venues) {
        try (FileWriter writer = new FileWriter(".\\Data\\venue_data.txt")) {
            for (String venue : venues) {
                writer.write(venue + "\n");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving venues.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    // Saving categories
    private void saveCategories(ArrayList<String> categories) {
        try (FileWriter writer = new FileWriter(".\\Data\\category_data.txt")) {
            for (String category : categories) {
                writer.write(category + "\n");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving categories.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
	/*public static void main(String[] args)
	{
		new AdminDashboard();
	}*/
}


