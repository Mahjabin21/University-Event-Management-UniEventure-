package classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import classes.*;

public class OrganizerDashboard extends JFrame implements ActionListener {
    private JPanel userPanel;
    private JTextField eventNameField, capacityField, selectedDateField;
    private JButton backButton, logoutButton, bookEventButton;
    private JLabel eventNameLabel, userNameLabel, welcomeLabel, venueLabel, capacityLabel, categoryLabel, slotLabel, selectDateLabel, availableSlotLabel;
    private JComboBox<String> venuesComboBox, categoriesComboBox, slots, availableSlots;
    private String username;

    public OrganizerDashboard(String username) {
        this.username = username;
        Event.loadEvents(); // Load all events from file

        // Background image setup 
        ImageIcon i1 = new ImageIcon("images/Event Background 1.jpeg");
        Image i2 = i1.getImage().getScaledInstance(700, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel backgroundImage = new JLabel(i3);
        backgroundImage.setBounds(0, 0, 700, 600);
        add(backgroundImage);

        // Side userPanel
        userPanel = new JPanel();
        userPanel.setBounds(0, 0, 230, 600);
        userPanel.setBackground(Color.decode("#04598d"));
        userPanel.setLayout(null); 
        backgroundImage.add(userPanel);

        // Profile logo inside the panel
        ImageIcon ii1 = new ImageIcon("images/Profile logo.png");
        Image ii2 = ii1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon ii3 = new ImageIcon(ii2);
        JLabel image1 = new JLabel(ii3);
        image1.setBounds(45, 50, 130, 130);
        userPanel.add(image1);
		
		// Username label below the profile
        userNameLabel = new JLabel(" " + username.toUpperCase());
        userNameLabel.setBounds(70, 190, 220, 50);
        userNameLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
        userNameLabel.setForeground(Color.WHITE);
        userPanel.add(userNameLabel);

        JLabel messageLabel1 = new JLabel("You are now proceeding");
        messageLabel1.setBounds(20, 260, 300, 30);
        messageLabel1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        messageLabel1.setForeground(Color.WHITE);
        userPanel.add(messageLabel1);

        JLabel messageLabel2 = new JLabel("as an organizer");
        messageLabel2.setBounds(50, 280, 300, 30);
        messageLabel2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        messageLabel2.setForeground(Color.WHITE);
        userPanel.add(messageLabel2);

        // Welcome label in user panel
        welcomeLabel = new JLabel("Welcome To UniEventure");
        welcomeLabel.setBounds(273, 30, 400, 40);
        welcomeLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 29));
        welcomeLabel.setForeground(Color.BLACK);
        backgroundImage.add(welcomeLabel);

        // Event name and field
        eventNameLabel = new JLabel("Event Name:");
        eventNameLabel.setBounds(270, 100, 160, 27);
        eventNameLabel.setFont(new Font("Serif", Font.BOLD, 23));
        backgroundImage.add(eventNameLabel);

        eventNameField = new JTextField();
        eventNameField.setFont(new Font("Serif", Font.BOLD, 15));
        eventNameField.setBounds(270, 140, 330, 30);
        eventNameField.setOpaque(false);
        backgroundImage.add(eventNameField);

        // Venue label and combo box
        venueLabel = new JLabel("Venue:");
        venueLabel.setBounds(270, 200, 150, 27);
        venueLabel.setFont(new Font("Serif", Font.BOLD, 23));
        backgroundImage.add(venueLabel);

        venuesComboBox = new JComboBox<>(loadVenues().toArray(new String[0]));
        venuesComboBox.setBounds(430, 200, 200, 30);
        venuesComboBox.setFont(new Font("Serif", Font.BOLD, 20));
        backgroundImage.add(venuesComboBox);

        // Add action listener to update available slots when venue is selected
        venuesComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateAvailableSlots();
            }
        });

        // Category label and combo box
        categoryLabel = new JLabel("Category:");
        categoryLabel.setBounds(270, 250, 200, 27);
        categoryLabel.setFont(new Font("Serif", Font.BOLD, 23));
        backgroundImage.add(categoryLabel);

        categoriesComboBox = new JComboBox<>(loadCategories().toArray(new String[0]));
        categoriesComboBox.setBounds(430, 250, 200, 30);
        categoriesComboBox.setFont(new Font("Serif", Font.BOLD, 23));
        backgroundImage.add(categoriesComboBox);

        // Slot label and combo box
        slotLabel = new JLabel("Selected Slot:");
        slotLabel.setBounds(270, 400, 200, 27);
        slotLabel.setFont(new Font("Serif", Font.BOLD, 23));
        backgroundImage.add(slotLabel);

        String slot[] = { " ", "9.00 am - 12.00 pm", "2.00 pm - 5.00 pm" };
        slots = new JComboBox<>(slot);
        slots.setBounds(430, 400, 200, 30);
        slots.setFont(new Font("Serif", Font.BOLD, 20));
        backgroundImage.add(slots);

        // Available slot
        availableSlotLabel = new JLabel("Available Slot:");
        availableSlotLabel.setBounds(270, 350, 200, 27);
        availableSlotLabel.setFont(new Font("Serif", Font.BOLD, 23));
        backgroundImage.add(availableSlotLabel);

        availableSlots = new JComboBox<>();
        availableSlots.setBounds(430, 350, 200, 30);
        availableSlots.setFont(new Font("Serif", Font.BOLD, 20));
        backgroundImage.add(availableSlots);

        // Select Date Label and field
        selectDateLabel = new JLabel("Select Date:");
        selectDateLabel.setBounds(270, 300, 200, 27);
        selectDateLabel.setFont(new Font("Serif", Font.BOLD, 23));
        backgroundImage.add(selectDateLabel);

        selectedDateField = new JTextField();
        selectedDateField.setFont(new Font("Serif", Font.BOLD, 15));
        selectedDateField.setBounds(430, 300, 200, 30);
        selectedDateField.setEditable(false);
        backgroundImage.add(selectedDateField);
        selectedDateField.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                new SelectDateFrame(OrganizerDashboard.this);
            }
        });

        // Add action listener to update available slots when date is selected
        selectedDateField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                updateAvailableSlots();
            }
        });

        bookEventButton = new JButton("Book Event");
        bookEventButton.setBounds(400, 470, 150, 40);
        bookEventButton.setForeground(Color.WHITE);
        bookEventButton.setBackground(new Color(77, 100, 137));
        bookEventButton.setFont(new Font("Poor Richard", Font.BOLD, 24));
        backgroundImage.add(bookEventButton);
        bookEventButton.addActionListener(this);

        backButton = new JButton("< Back");
        backButton.setFont(new Font("Times new roman", Font.BOLD, 18));
        backButton.setForeground(Color.BLACK);
        backButton.setBackground(new Color(172, 209, 228));
        backButton.setBounds(55, 410, 120, 40);
		backButton.addActionListener(this);
        userPanel.add(backButton);

        logoutButton = new JButton("Log  Out");
        logoutButton.setFont(new Font("Times new roman", Font.BOLD, 18));
        logoutButton.setForeground(Color.BLACK);
        logoutButton.setBackground(new Color(172, 209, 228));
        logoutButton.setBounds(55, 470, 120, 40);
		logoutButton.addActionListener(this);
        userPanel.add(logoutButton);

        setSize(700, 600);
        setLocation(280, 60);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
   
   private ArrayList<String> loadVenues() {
    ArrayList<String> venues = Event.loadVenues();
    venues.add(0, " ");
    return venues;
}

private ArrayList<String> loadCategories() {
    ArrayList<String> categories = Event.loadCategories();
    categories.add(0, " ");
    return categories;
}

private void validateEventBooking() {
    String eventName = eventNameField.getText();
    String selectedVenue = (String) venuesComboBox.getSelectedItem();
    String selectedCategory = (String) categoriesComboBox.getSelectedItem();
    String selectedSlot = (String) slots.getSelectedItem();
    String selectedDate = selectedDateField.getText();

    // Validation check for fields
    if (eventName.isEmpty() || selectedVenue.equals(" ") || selectedCategory.equals(" ") ||
        selectedSlot.equals(" ") || selectedDate.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill all fields to book the event.");
    } else {
        // Check for slot clashes and book event if valid
        if (Event.isClash(selectedVenue, selectedDate, selectedSlot)) {
            JOptionPane.showMessageDialog(this, "The selected slot is already booked for this venue on the same date.");
        } else {
            Event newEvent = new Event(eventName, selectedVenue, selectedCategory, selectedDate, selectedSlot," ");
            Event.bookNewEvent(newEvent);
            JOptionPane.showMessageDialog(this, "Event booked successfully!");

            // Clear fields after successful booking
            eventNameField.setText("");
            venuesComboBox.setSelectedIndex(0);
            categoriesComboBox.setSelectedIndex(0);
            slots.setSelectedIndex(0);
            selectedDateField.setText("");
        }
    }
}

private void updateAvailableSlots() {
	
    String selectedVenue = (String) venuesComboBox.getSelectedItem();
    String selectedDate = selectedDateField.getText();

    if (!selectedVenue.equals(" ") && !selectedDate.isEmpty()) {
        ArrayList<String> available = Event.getAvailableSlots(selectedVenue, selectedDate);
        availableSlots.removeAllItems();
        for (String slot : available) {
            availableSlots.addItem(slot);
        }
    }
	
}

public void setSelectedDate(String date) {
    selectedDateField.setText(date);
    updateAvailableSlots();
}

public void actionPerformed(ActionEvent e) {
    if (e.getSource() == bookEventButton) {
        validateEventBooking();
    }
    if (e.getSource() == backButton) {
        new UserDashboard(this.username);
        this.dispose();
    }
    if (e.getSource() == logoutButton) {
        new Login();
        this.dispose();
    }
}
}